# HTTP request GET/POST in Java

From: How to send HTTP request GET/POST in Java
https://www.mkyong.com/java/how-to-send-http-request-getpost-in-java/

